	<div class="row" >
				<div class="panel panel-default"style="background:#005cb0; color:#FFF">
					<div class="panel-body">
						<div class="col-md-4">
						Clinical Medical Reviews and Case Reports<br>
						International Journal of Neurology and Neurotherapy<br>
						International Journal of Immunology and Immunotherapy<br>
						Obstetrics and Gynaecology Cases - Reviews<br>
						International Journal of Clinical Cardiology<br>
						Journal of Genetics and Genome Research<br>
						International Journal of Virology and AIDS
						</div>
						<div class="col-md-4">
						Clinical Medical Reviews and Case Reports<br>
						International Journal of Neurology and Neurotherapy<br>
						International Journal of Immunology and Immunotherapy<br>
						Obstetrics and Gynaecology Cases - Reviews<br>
						International Journal of Clinical Cardiology<br>
						Journal of Genetics and Genome Research<br>
						International Journal of Virology and AIDS
						</div>
						<div class="col-md-4">
						Clinical Medical Reviews and Case Reports<br>
						International Journal of Neurology and Neurotherapy<br>
						International Journal of Immunology and Immunotherapy<br>
						Obstetrics and Gynaecology Cases - Reviews<br>
						International Journal of Clinical Cardiology<br>
						Journal of Genetics and Genome Research<br>
						International Journal of Virology and AIDS
						</div>
					</div>
				</div>
			</div>
		
		
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>