<html>
<head>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
<script src="SSS-master/sss/sss.min.js"></script>
<link rel="stylesheet" href="SSS-master/sss/sss.css" type="text/css" media="all">

<script>
jQuery(function($) {
$('.slider').sss();
});
</script>



</head>
<body>
<!------------
<ul class="bxslider">
  <li><img src="/bxslider/img/tree_root.jpg" title="Funky roots" /></li>
  <li><img src="/bxslider/img/hill_road.jpg" title="The long and winding road" /></li>
  <li><img src="/bxslider/img/trees.jpg" title="Happy trees" /></li>
</ul>
----------------------------------------->


<div class="slider" style="width:800px;">
<img src="SSS-master/img/1.jpg" />
<img src="SSS-master/img/2.jpg" />
<img src="SSS-master/img/3.jpg" />
</div>

</body>
</html>