<h4 class="heading-primary">About the Journal</h4>
	<p align="justify" class="para1">
	<img width="280" align="right" style="margin-left:10px;" src="../images/ijc.jpg">
		ClinMed International Library - "Evergreen International Journal Archive" that publishes findings in the laboratory to the advancement of clinical practice and advancement of medical research that extends our understanding and improves the treatment of human diseases. CMIL is the premier venue for critical advances in clinical and medical research, authoritative reviews, cases and commentaries that place research articles in context. This online library delivers and supports highly affiliated professionals and researchers across the globe. CMIL provides quick decisions enhancing the quality medical editing objectives and publishing quality articles at its best to the authors. CMIL is an open access clinical and medical forum following international ethical norms to satisfy the readers or academician at every aspect. ClinMed International Library - "Evergreen International Journal Archive" that publishes findings in the laboratory to the advancement of clinical practice and advancement of medical research that extends our understanding and improves the treatment of human diseases. CMIL is the premier venue for critical advances in clinical and medical research, authoritative reviews, cases and commentaries that place research articles in context. This online library delivers and supports highly affiliated professionals and researchers across the globe. CMIL provides quick decisions enhancing the quality medical editing objectives and publishing quality articles at its best to the authors. CMIL is an open access clinical and medical forum following international ethical norms to satisfy the readers or academician at every aspect.
	</p>
	
<div class="row">
					<div class="col-lg-9">
						<div class="panel panel-info" >
						<div class="panel-heading">
						What's New
						</div>
							<p align="justify" class="para1">ClinMed International Library - "Evergreen International Journal Archive" that publishes findings in the laboratory to the advancement of clinical practice and advancement of medical research that extends our understanding and improves the treatment of human diseases. CMIL is the premier venue for critical advances in clinical and medical research, authoritative reviews, cases and commentaries that place research articles in context. This online library delivers and supports highly affiliated professionals and researchers across the globe. CMIL provides quick decisions enhancing the quality medical editing objectives and publishing quality articles at its best to the authors. CMIL is an open access clinical and medical forum following international ethical norms to satisfy the readers or academician at every aspect. </p>
						</div>
						<div class="panel panel-info" >
						<div class="panel-heading">
						What's New
						</div>
							<p align="justify" class="para1">ClinMed International Library - "Evergreen International Journal Archive" that publishes findings in the laboratory to the advancement of clinical practice and advancement of medical research that extends our understanding and improves the treatment of human diseases. CMIL is the premier venue for critical advances in clinical and medical research, authoritative reviews, cases and commentaries that place research articles in context. This online library delivers and supports highly affiliated professionals and researchers across the globe. CMIL provides quick decisions enhancing the quality medical editing objectives and publishing quality articles at its best to the authors. CMIL is an open access clinical and medical forum following international ethical norms to satisfy the readers or academician at every aspect. </p>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="panel panel-info" >
						<div class="panel-heading">
						Info
						</div>
							<p align="justify" class="para1" style="margin:10px;">
							ClinMed International Library - "Evergreen International Journal Archive" that publishes findings in the laboratory to the advancement of clinical practice and advancement of medical research that extends our understanding and improves the treatment of human diseases. CMIL is the premier venue for critical advances in clinical and medical research, authoritative reviews, cases and commentaries that place research articles in context. This online library delivers and supports highly affiliated professionals and researchers across the globe. CMIL provides quick decisions enhancing the quality medical editing objectives and publishing quality articles at its best to the authors. CMIL is an open access clinical and medical forum following international ethical norms to satisfy the readers or academician at every aspect.</P>							
						
						</div>
					</div>
				</div>	